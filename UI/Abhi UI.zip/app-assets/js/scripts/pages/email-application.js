//  Notifications & messages scrollable
if($('#users-list').length > 0){
	var users_list = new PerfectScrollbar("#users-list");
}